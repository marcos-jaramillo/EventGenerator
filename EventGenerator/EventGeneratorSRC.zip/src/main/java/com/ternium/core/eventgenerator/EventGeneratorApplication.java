package com.ternium.core.eventgenerator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.ternium.core.eventgenerator.util.KieServerProperties;
import com.ternium.core.eventgenerator.util.SparkProperties;

@SpringBootApplication
@EnableConfigurationProperties({SparkProperties.class, KieServerProperties.class})
public class EventGeneratorApplication {
	private static Logger logger = LoggerFactory.getLogger(EventGeneratorApplication.class); 

	public static void main(String[] args) {
		SpringApplication.run(EventGeneratorApplication.class, args);
	}
    
}
