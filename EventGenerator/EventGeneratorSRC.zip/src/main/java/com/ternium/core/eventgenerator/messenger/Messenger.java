package com.ternium.core.eventgenerator.messenger;

public interface Messenger {
	public void sendMessage(String message) throws Exception;
}
