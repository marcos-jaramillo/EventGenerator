package com.ternium.core.eventgenerator;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class EventGeneratorApplicationTests {

	//@Test
	void contextLoads() {
	}

}
